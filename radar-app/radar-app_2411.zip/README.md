# radar-app
Interfaz del radar de la aplicación TDC, implementado en Electron.
